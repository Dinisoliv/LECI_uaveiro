package APFinal;

public enum typeEvent {
    MUSIC,
    CINEMA,
    THEATRE
}
