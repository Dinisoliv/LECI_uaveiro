# Exercícios de exames práticos antigos.

Esta pasta contém enunciados de problemas propostos em
exames práticos finais em anos anteriores.
Use-os para rever e praticar o que aprendeu.

Bom estudo.

