import os

def clear_powershell_console():
    os.system('cls')  # for Windows

# Call the function to clear the PowerShell console
clear_powershell_console()

print("Hello world")