import random

# Lista de palavras para o jogo da forca

palavras = ["desconcentrar\u00e3o", "esparramar\u00e3o", "despist\u00e1sseis", "apre\u00e7adoras", "reentregar\u00edamos", "entup\u00edssemos", "bolorec\u00edeis", "brilh\u00e1mos", "apalacian\u00e1vamos", "inch\u00e1ssemos", "exteriorizar\u00edamos", "estarrec\u00earamos", "reposicion\u00e1ssemos", "migrar\u00e3o", "administr\u00e1ramos", "sachar\u00e1", "remagnetiz\u00e1vamos", "desfranj\u00e1sseis", "encru\u00e1reis", "enxurrar\u00e1", "desamotin\u00e1sseis", "gigantizar\u00edamos", "debilit\u00e1vamos", "embarracar\u00edamos", "concit\u00e1veis", "desaromatizar\u00e3o", "embandeir\u00e1vamos", "eleva\u00e7\u00e3o", "empobrecer\u00edamos", "transport\u00e1vel", "torrificar\u00edamos", "in\u00e7ar\u00edeis", "linch\u00e1mos", "cirand\u00e1vamos", "resenhar\u00e3o", "hexacampe\u00f5es", "demand\u00e1reis", "esmalt\u00e1mos", "medalh\u00e1reis", "mesclar\u00e3o", "naufragar\u00edamos", "escusar\u00edamos", "desnorte\u00e1reis", "dep\u00f3sito", "desencarapu\u00e7assem", "conson\u00e1veis", "agrimensar\u00edamos", "prostitu\u00eddos", "rejubilar\u00e1s", "perisc\u00f3pico", "avult\u00e1ramos", "explor\u00e1veis", "baloi\u00e7ais", "descarnar\u00e3o", "incompatibiliz\u00e1ramos", "infernizar\u00e1s", "repens\u00e1veis", "desamolg\u00e1ssemos", "atafulh\u00e1ssemos", "conglomer\u00e1tico", "paleol\u00edtica", "moinar\u00edeis", "agraf\u00e1ssemos", "recravar\u00edamos", "arru\u00e7armos", "destrin\u00e7ador", "vermelha\u00e7o", "joelhar\u00e1s", "envidra\u00e7am", "agricult\u00e1ssemos", "amoralizar\u00edamos", "sabichar\u00e1s", "icon\u00f3filo", "embaralhar\u00e1", "imortaliz\u00e1veis", "abra\u00e7\u00e1vamos", "afret\u00e1vamos", "minutar\u00e3o", "infant\u00e1rios", "embainhar\u00edamos", "co\u00e7aremos", "refogar\u00e1", "reagrup\u00e1reis", "desentup\u00edeis", "avi\u00e1reis", "crucificar\u00edamos", "sobreluz\u00edssemos", "almo\u00e7ai", "acen\u00e1mos", "temporiz\u00e1ramos", "calor\u00edficas", "boicote\u00e1reis", "abstra\u00edssemos", "inclu\u00edramos", "espoli\u00e1ramos", "esquematizar\u00e1s", "enfaixar\u00e3o", "ajoelhar\u00e3o", "incont\u00ednuo", "restituir\u00e1", "indesment\u00edveis", "esvoa\u00e7ares", "desencravar\u00edeis", "agrimens\u00e1vamos", "acomodar\u00e1s", "espa\u00e7amento", "refortalec\u00easseis", "risc\u00e1ssemos", "problematiz\u00e1veis", "embrulh\u00e1vamos", "ro\u00e7aria", "provoc\u00e1ssemos", "oftalmol\u00f3gicas", "repuxar\u00edamos", "cancer\u00e1sseis", "suborna\u00e7\u00e3o", "florir\u00edeis", "encancer\u00e1mos", "esperan\u00e7ado", "pux\u00f5es", "atordo\u00e1mos", "esgrim\u00edamos", "menorizar\u00e1", "guilhotinar\u00e1s", "destitu\u00eda", "desbravar\u00e1s", "embrion\u00e1rias", "enchouri\u00e7aras", "desaparelhar\u00e3o", "recargar\u00e1s", "co\u00e1gulo", "instru\u00edas", "eleg\u00eassemos", "circunstanci\u00e1ramos", "autom\u00f3rfico", "educar\u00e3o", "retornar\u00edamos", "andr\u00f3fobas", "individualizar\u00edeis", "embustear\u00edamos", "evid\u00eancias", "desburocratizar\u00e3o", "ressaud\u00e1veis", "of\u00eddeos", "abobor\u00e1veis", "potenci\u00e1ssemos", "polic\u00eantrico", "tens\u00f5es", "jorrar\u00edamos", "pespeg\u00e1reis", "reabita\u00e7\u00e3o", "eclipsar\u00e1", "vici\u00e1reis", "baston\u00e1rias", "amorda\u00e7ar\u00e1", "temporizar\u00e1", "movimentar\u00edamos", "reemigrar\u00edamos", "estenogr\u00e1ficas", "ex\u00edmios", "indisfar\u00e7\u00e1veis", "certifica\u00e7\u00e3o", "helenizar\u00edeis", "despenhar\u00e1s", "redobr\u00e1ramos", "desprogram\u00e1ramos", "gravidar\u00edamos", "apedrej\u00e1ssemos", "espica\u00e7adelas", "lassar\u00e1s", "revi\u00e9ramos", "metamorfosear\u00edamos", "trope\u00e7o", "apedr\u00e1mos", "imortaliz\u00e1ssemos", "\u00eanclise", "solit\u00e1rias", "chocalh\u00e1sseis", "seri\u00e1mos", "abomin\u00e1vel", "falec\u00eassemos", "aterr\u00e1sseis", "amuralh\u00e1vamos", "clept\u00f3mana", "circulat\u00f3ria", "antecip\u00e1mos", "encorrilh\u00e1vamos", "mnemoniz\u00e1ramos", "enceleirar\u00e3o", "silv\u00e1ssemos", "dinamit\u00e1vamos", "dign\u00e1sseis", "petroqu\u00edmica", "pratic\u00e1reis", "canoniz\u00e1sseis", "encamisar\u00e3o", "incorp\u00f3reo", "opi\u00e1veis", "desalfandegar\u00e1s", "destro\u00e7ava", "ur\u00f3logas", "patarate\u00e1vamos", "pel\u00e1ramos", "esmurr\u00e1mos", "catit\u00e1ssemos", "impel\u00edamos", "enfolhar\u00edamos", "aclimat\u00e1ramos", "esbarr\u00e1veis", "derroc\u00e1reis", "afeg\u00e3os", "clement\u00edssimos", "afunilar\u00edamos", "inimit\u00e1vel", "desleix\u00e1vamos", "rumar\u00e1", "id\u00edlicos", "degener\u00e1veis", "republicaniz\u00e1veis", "rogat\u00f3rias", "xarop\u00e1ramos", "volt\u00e1veis", "come\u00e7adas", "jogar\u00e1", "sorv\u00edamos", "aben\u00e7oaremos", "desmonopoliz\u00e1reis", "fervilh\u00e1vamos", "miracul\u00e1mos", "acend\u00easseis", "maced\u00f3nia", "apequenar\u00edeis", "cascate\u00e1ssemos", "marinar\u00e3o", "quez\u00edlias", "artol\u00e1reis", "t\u00f3xicas", "imbuir\u00edamos", "aprovisionar\u00e1", "instil\u00e1veis", "conso\u00e1ssemos", "lamb\u00edeis", "alhear\u00e3o", "mortific\u00e1vamos", "desembrulhar\u00edeis", "redescontar\u00e1s", "respond\u00edveis", "compreender\u00e1", "ging\u00e1ssemos", "dan\u00e7aricam", "pesponteasses", "pinotearem", "engendrou", "indemnizarmos", "aconsoantarias", "arreste", "estereotiparam", "enfastiariam", "estratificaremos", "soltastes", "fraseaste", "prosseguem", "discursai", "gretasse", "ratazanassem", "infamai", "charlataneie", "descomoveres", "convivida", "coreografasses", "arrematador", "presbiteriano", "aurificara", "saberiam", "fenderem", "defensasses", "balbuciais", "imputes", "inaugurardes", "impopularizavas", "individuadora", "encurralam", "negada", "mesquinhamos", "cartografastes", "arrancaria", "arboresceram", "enegrece", "refendera", "passivei", "stops", "abaixarmos", "suspendemos", "intrigarem", "festejava", "razoabilidade", "plebeizarei", "berregaras", "munjas", "serradelas", "sobreporeis", "desmobiladas", "quintuplicados", "galasse", "despovoam", "fanicaremos", "desincorporam", "houvesses", "deferiria", "ornamentamos", "retardamos", "boche", "renavego", "mutilariam", "rosal", "decretarei", "atesses", "incidisse", "antemuradas", "pestilentas", "bafeja", "guardavas", "evocava", "concorrera", "catalisemos", "esmurrava", "desenjoaram", "acalentareis", "avizinharem", "clareiem", "atempam", "viciar", "motivavas", "ziguezagueaste", "repudies", "grisarem", "postularmos", "averiguai", "peladas", "algebrizados", "desengracemos", "enfolhastes", "paparicarem", "retires", "consistirmos", "flava", "bulemos", "foscasses", "arribais", "aresteiros", "indente", "abrigaras", "trasladai", "bolastes", "ilharas", "assombraras", "ratazanardes", "selecionas", "ironizados", "passivos", "aparentada", "sinalizariam", "apropositavam", "desempanais", "arrumados", "endividasse", "iluminava", "seja", "desunifiqueis", "horda", "raptaste", "quesitos", "presasses", "comunicarmos", "carrilhonais", "urdimentos", "herdarem", "transportaram", "dengue", "ravinemos", "avessareis", "subinspetoras", "reclamaria", "noivavam", "ramificai", "tragasses", "estilos", "descalcificaram", "acalcado", "afilhe", "sacarmos", "repoises", "coliga", "reaparecido", "redimensionava", "adentras", "massacrar", "nevarias", "compaginardes", "assopraria", "tratanteado", "necessitados", "vareira", "cedilhados", "levedaria", "carimba", "despertos", "impermeabilizados", "ordenadas", "varejareis", "resigno", "farrapava", "rebelei", "desembalarem", "girou", "macerassem", "soou", "desinfestarmos", "loireceres", "lesamos", "cometeste", "coadquirireis", "hebraizarem", "afumam", "genealogista", "festejador", "laureio", "governasse", "redigirias", "esfregadoras", "maquinara", "concetualizes", "particularizarmos", "aquadrilhares", "caracolavas", "abastonares", "rasgamentos", "escolarizarem", "abrasaram", "incense", "soberanas", "falsificador", "extasiares", "arregramos", "brutais", "desencabelarem", "labializeis", "reprogramaria", "arrefentasse", "conceituarem", "desengrenaram", "ostentada", "rabequearemos", "atedie", "debicarem", "imaginadoras", "aduzias", "desagoniara", "redondeai", "limpadores", "desbastadora", "topeis", "exulariam", "evangelizarem", "envinagravas", "nitratavam", "brotasses", "excursionastes", "emulsionantes", "descoordenais", "embatoco", "turqueses", "calcorrearem", "reacoplaste", "pontificarmos", "lavraram", "remastigado", "rebula", "musicaria", "ladrilheis", "repusesse", "respigava", "enxugou", "individuam", "assumira", "desencapareis", "profetizado", "maluquearas", "participativo", "aclimatizeis", "interrompi", "baseavas", "malogrem", "mediocrizareis", "arredei", "intensificada", "individualizais", "quicos", "enveredareis", "autocopiarem", "perdularia", "doutros", "exclamaremos", "orlassem", "desvendaram", "assotado", "macaquinho", "malcozestes", "comprometi", "prestabilidade", "desabitasse", "figurinista", "muralhares", "narcotizam", "anilhassem", "coreografais", "pardacenta", "escrevinharmos", "malcozerem", "vendereis", "enervamento", "gorjeaste", "aprefixareis", "recavara", "seixal", "fotografaras", "adestrasse", "talheres", "acordam", "analfabeta", "prosperas", "desgrenharas", "sinonimizadas", "gozamos", "acresciam", "infundindo", "rebatizariam", "assapatada", "mundializarei", "ensebe", "permutada", "rebolamos", "gravitassem", "cochadas", "regrassem", "quartinho", "vitimaste", "refortificarmos", "nefasto", "burrificareis", "fortaleceram", "minorariam", "rastejarmos", "desencarrilavam", "flauteara", "nanaras", "antevendo", "intermediaram", "pernoutarias", "prosardes", "confidenciais", "desconvertias", "universalize", "abjudiqueis", "esfuziamos", "causticando", "acoimassem", "profissionalizaram", "progressivas", "perdoada", "reembarcando", "engradearmos", "cortado", "atoucinhem", "entrevereis", "estardalhas", "superlativares", "postuladores", "rusgado", "rascasses", "negoceias", "seletivas", "desunirias", "coroarem", "atraiais", "murmurejo", "atentes", "blasfemaria", "preporia", "preestabelecemos", "agrediam", "azulejareis", "saltitais", "ancestralmente", "desvenero", "sobejada", "vociferadas", "realizava", "aproximarem", "tossicardes", "reinscritos", "brecando", "descampadas", "amealhador", "malbaratadores", "encalacrai", "sustando", "adjetivares", "revirava", "pousarem", "quiromancia", "quadruplaste", "garantirmos", "coloreie", "expiarem", "traduzo", "farolizavam", "vassourardes", "barcarola", "delimitadas", "obtenham", "desnorteara", "espionaria", "tarifarei", "contraproporemos", "selaras", "marcho", "complanem", "relocalizes", "escapulias", "amourariam", "originavas", "inflamo", "ocultadas", "desqualificaste", "emparceleis", "inversamente", "jurai", "ameigado", "marearei", "malfadei", "ensacastes", "corricariam", "enforcaras", "cascalhou", "legitimam", "navalhou", "gaguejaremos", "reconsideraste", "policie", "cinematografa", "dealbavam", "baralhemos", "validassem", "afranzinastes", "sortira", "caldeirara", "orquestrariam", "representariam", "tacanhearia", "desmandasse", "croniquem", "inscrevi", "crepusculizeis", "revisaria", "tilintante", "quebraria", "benzo", "desestagnara", "bolinaras", "municipalizai", "desacataste", "enfiamentos", "engane", "retaliasses", "dando", "resolverem", "estrebuchamento", "calejavas", "desnaturarem", "introdutivo", "enrolhar", "depositaremos", "escrevinhadora", "impossibilitardes", "arade", "atarantamento", "circunscreveremos", "desencaminheis", "nicotino", "anotada", "inovaremos", "maxilares", "invetivai", "cigarrardes", "carcinomas", "refloristes", "aloirem", "frustradora", "aniversariardes", "gabem", "repescadas", "fugiria", "sufocaste", "ziguezagueavam", "terrificaram", "denudado", "rotores", "fungando", "menosprezos", "portugalizariam", "descarregar", "enquadrar", "acreditaras", "idolatro", "reequilibrasse", "prosperasses", "inconformai", "desencabelasse", "pedantearem", "contextualizarmos", "colapsasse", "estontece", "reexpedissem", "idolatrasse", "compulse", "acantonavas", "romanceardes", "atroparias", "filatelismos", "argumentais", "acobardardes", "alvissaravam", "revistemos", "menorizei", "bromeis", "resumes", "individuarem", "gananciavam", "desencorajas", "amontoaste", "segregarias", "reiteravam", "recompense", "rabujem", "desencorajas", "goelaria", "ilegalizei", "desmineralizamos", "caulificamos", "pulsei", "absorveria", "erigido", "atroador", "acometedoras", "destinais", "quotizarmos", "pasteleiras", "reabririas", "navegando", "passearem", "investirem", "dissimular", "mascares", "insularem", "pincelarias", "surpreendido", "prolongas", "drenarias", "sinalizarias", "empastavas", "enrabichardes", "dopou", "retingistes", "promovi", "retalhadoras", "fidelizareis", "arvorarmos", "marretemos", "desabituo", "monetizares", "praguejais", "comerciaras", "oceanicidades", "desintegras", "conservantistas", "influencies", "passeata", "ruja", "andamento", "cavalgareis", "abusassem", "rixares", "incitares", "descapitalizaras", "aventes", "regerariam", "desmentias", "macro", "contentavas", "impermeabilizas", "aclimate", "espionai", "namorais", "vendavam", "destrones", "guitarrearem", "capacitem", "algebrizam", "reciprocarias", "recobriras", "infestara", "catolize", "impuseste", "distendidas", "tateado", "traseiros", "surgimento", "indultara", "amontoai", "ensaboarem", "sanita", "turbasses", "desquitarem", "hebraizamos", "desaclimatai", "subavaliares", "esganadas", "biforme", "desencardiriam", "gaspearam", "desamontoada", "apipasse", "tossiras", "dependuravam", "lambearei", "sinfonizavas", "agasalhastes", "anavalhou", "espancava", "desnasalasse", "fardaram", "sabotava", "pantanizei", "narramos", "devotava", "acudires", "recompraras", "reexportou", "aeroportos", "subscreverias", "assanhasses", "colardes", "castificados", "abanemos", "entesoirassem", "instais", "ecopontos", "enluvando", "bananeiro", "fingistes", "acobardando", "movimentem", "aquinhoei", "predefiniras", "derrogava", "faturava", "principescos", "degelam", "grandeza", "oveis", "malfizeres", "biscouto", "estoures", "aterrorizes", "arrasarias", "ingerisse", "ementaria", "analises", "encetais", "evacuasses", "elipsoidal", "dualizando", "desagravaria", "armazenamentos", "conformara", "atines", "amargavas", "autonomizou", "restringias", "encurralaste", "corpanzil", "teledirija", "hermetismos", "compreendiam", "ambientes", "aderidos", "convirmos", "enrascados", "patinhara", "dogmatizando", "emergindo", "debrucemos", "paroquiaram", "choraminguei", "existiremos", "desacomodais", "coordenemos", "encartavam", "amontanhavam", "substituindo", "sancionares", "ocidentalizem", "lentejoulemos", "reavistes", "formularam", "assolape", "exaltarias", "safra", "delirardes", "escandalizar", "redutos", "aconselharia", "engalfinhei", "gracejariam", "preestabelece", "ressalvares", "lampejava", "chalreadas", "progrida", "indexadora", "concernira", "acarretam", "matinada", "industriareis", "alavancamos", "loucura", "ansiais", "berloques", "dignificadas", "foliar", "transitivarei", "insuflai", "primorosa", "seborreia", "encarcerarei", "reincides", "aposentastes", "miserem", "impropriavam", "modularidade", "floresceis", "germanizadas", "descomprometeremos", "gravidarmos", "amourar", "ambicionou", "extrais", "escanhoaram", "recavado", "digressionou", "ravinai", "chi", "casquilhou", "sibilantizaras", "discordem", "peralteaste", "xisto", "reescalonassem", "cavaleirareis", "abrigaria", "cacicada", "acarretardes", "mim", "interventivas", "decomponibilidade", "mercadejaria", "barulharam", "despenteares", "lavoiras", "prejudicaste", "cauteleiro", "ginasial", "desinfecionareis", "amarrotada", "letargias", "emparcelarem", "escalfaram", "dezassete", "adentrada", "despejassem", "esquadria", "redobradas", "analisarmos", "repovoados", "despeitora", "bocadinhos", "existires", "indutores", "corujasse"]


# Escolhe uma palavra aleatoriamente
palavra = random.choice(palavras).lower()  # Converte a palavra para minúsculas
letras_corretas = set()
letras_erradas = set()
tentativas_maximas = 7

def mostrar_forca(erros):
    desenho_forca = [
        """
           ______
          |      |
                 |
                 |
                 |
                 |
        """,
        """
           ______
          |      |
          O      |
                 |
                 |
                 |
        """,
        """
           ______
          |      |
          O      |
          |      |
                 |
                 |
        """,
        """
           ______
          |      |
          O      |
         /|      |
                 |
                 |
        """,
        """
           ______
          |      |
          O      |
         /|\\     |
                 |
                 |
        """,
        """
           ______
          |      |
          O      |
         /|\\     |
         /       |
                 |
        """,
        """
           ______
          |      |
          O      |
         /|\\     |
         / \\     |
                 |
        """
    ]

    if erros < len(desenho_forca):
        return desenho_forca[erros]
    else:
        return desenho_forca[-1]

def mostrar_palavra(palavra, letras_corretas):
    resultado = ''
    for letra in palavra:
        if letra in letras_corretas:
            resultado += letra
        else:
            resultado += '_'
    return resultado

def letras_restantes(palavra, letras_corretas):
    return set(palavra) - letras_corretas

def remove_acentos(palavra):
    # Função para remover acentos e cedilhas
    acentos = {'á': 'a', 'à': 'a', 'â': 'a', 'ã': 'a', 'é': 'e', 'è': 'e', 'ê': 'e', 'í': 'i', 'ì': 'i', 'î': 'i',
               'ó': 'o', 'ò': 'o', 'ô': 'o', 'õ': 'o', 'ú': 'u', 'ù': 'u', 'û': 'u', 'ç': 'c'}
    for acento, letra in acentos.items():
        palavra = palavra.replace(acento, letra)
    return palavra

erros = 0  # Variável para contar os erros

while True:
    print("\n" + mostrar_forca(erros))
    print(mostrar_palavra(palavra, letras_corretas))
    print("Letras erradas:", ' '.join(sorted(letras_erradas)))
    print("Número de erros:", erros)  # Mostra o número de erros

    if mostrar_palavra(palavra, letras_corretas) == palavra:
        print("\nParabéns, você ganhou! A palavra era:", palavra)
        break

    if erros == tentativas_maximas:
        print("\nVocê perdeu! A palavra era:", palavra)
        break

    letra = input("Adivinhe uma letra: ").lower()

    if len(letra) != 1 or not letra.isalpha():
        print("Por favor, insira uma única letra válida.")
        continue

    letra = remove_acentos(letra)

    if letra in letras_corretas or letra in letras_erradas:
        print("Você já adivinhou esta letra.")
        continue

    if letra in palavra:
        letras_corretas.add(letra)
    else:
        letras_erradas.add(letra)
        erros += 1
